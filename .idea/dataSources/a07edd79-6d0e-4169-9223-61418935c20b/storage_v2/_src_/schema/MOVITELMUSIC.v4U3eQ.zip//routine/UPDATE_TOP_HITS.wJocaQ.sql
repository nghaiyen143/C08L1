create PROCEDURE UPDATE_TOP_HITS AS
BEGIN
    INSERT INTO CHARTS
    VALUES (CHARTS_SEQ.nextval,
            TO_NUMBER(TO_CHAR(SYSDATE - 7, 'IW')),
            TRUNC(SYSDATE, 'IW') - 7,
            TRUNC(SYSDATE, 'IW') - 1 / 86400);

    INSERT INTO CHARTS_SONG (ID, RANK, CHARTS_ID, SONG_ID)
    SELECT CHARTS_SONG_SEQ.nextval, ths.RANK, ths.CHART_ID, ths.SONG_ID
    FROM (SELECT rn                                                                                       as RANK,
                 s.ID                                                                                     as SONG_ID,
                 (SELECT ID FROM (SELECT c.ID FROM CHARTS c ORDER BY c.START_DATE DESC) WHERE ROWNUM = 1) as CHART_ID
          FROM SONG s
                   INNER JOIN (SELECT ls.SONG_ID,
                                      SUM(ls.NUMBER_LISTEN)                                   as listen,
                                      ROW_NUMBER() OVER (ORDER BY SUM(ls.NUMBER_LISTEN) DESC) as rn
                               FROM LOG_SONG_LISTEN ls
                               WHERE ls.TYPE = 'AUDIO'
                                 AND ls.DATE_CREATE BETWEEN TRUNC(SYSDATE, 'IW') - 7 AND TRUNC(SYSDATE, 'IW')
                               GROUP BY ls.SONG_ID
                               ORDER BY listen DESC) b ON s.ID = b.SONG_ID
          WHERE s.STATUS = 'PUBLISHED'
            AND rn <= 100
          ORDER BY listen DESC) ths;
END;
/

