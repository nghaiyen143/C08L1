create TYPE "NAME_AND_COUNT_ARRAY" IS VARRAY(30) OF name_and_count_t;

/

